package com.testing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExcelDownloadApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExcelDownloadApplication.class, args);
	}

}
